### This is uBlock's manifesto

1. The **user decides** what web content is acceptable or not in their browser.

The uBlock project does not support Adblock Plus' _"Acceptable Ads Manifesto"_,
because the _"Acceptable Ads"_ marketing campaign is really the business
plan of a for-profit entity.

Users are best placed to know what is or is not acceptable to them. uBlock's
sole purpose is to give users the means to enforce their own choices.
